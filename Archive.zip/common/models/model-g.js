module.exports = function(ModelG) {

};
