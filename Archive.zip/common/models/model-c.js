module.exports = function(ModelC) {

};
